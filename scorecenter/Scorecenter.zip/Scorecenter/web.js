//express support
var express = require('express');
var app = express.createServer(express.logger());
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
app.use(express.bodyParser());
app.set('title', 'scorecenter');
app.use('/js', express.static(process.env.PWD+'/js'));

// Mongo/mongoose initialization
var mongoose = require('mongoose');
mongoose.connect(process.env.MONGOLAB_URI || 
  process.env.MONGOHQ_URL || 
  'mongodb://localhost/scorecenter');
  
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function callback () {
  console.log("opened");
  var scoreSchema = mongoose.Schema({
    game_title: String,
    username: String,
    score: Number,
    created_at: Date
  });
  Score = mongoose.model('Score', scoreSchema);
});



app.get('/', function(request, response) {
  Score.find(function(err, scores) {
       if (err) console.log("error");
       var rstring = "<table><caption>User Scores</caption><thead><tr><th>Game</th><th></th><th>User</th><th></th><th>Score</th><th></th><th>Date</th></tr></thead><tbody>";
       for (var i=0;i<scores.length;i++) {
         rstring += "<tr><td>";
         rstring += scores[i]['game_title'];
         rstring += "</td><td></td><td>";
         rstring += scores[i]['username'];
         rstring += "</td><td></td><td>";
         rstring += scores[i]['score'];
         rstring += "</td><td></td><td>";
         rstring += scores[i]['created_at'];
         rstring += "</td></tr>";
       }
       rstring += "</tbody></table>";
       response.send(rstring);
  });
});

app.get('/usersearch', function(request, response) {
    
	response.send('<script src="js/jquery.js"></script><script src="js/getscores.js"></script><h1>Enter a name:</h1><input type="text" id="input" size="30"/><button type="submit" id="submit" onclick="getScores();">Submit</button><div id="scores"></div>');
});

//sending data from my machine to web server
app.post('/submit.json', function(request, response){
	response.header("Access-Control-Allow-Origin", "*");
    response.header("Access-Control-Allow-Headers", "X-Requested-With");
	var username = request.body.username;
	var userscore = parseInt(request.body.score);
	var usergame = request.body.game_title;
	var d = new Date();
	var newScore = new Score({ game_title: usergame, username: username, score: userscore, created_at: d });
    newScore.save(function (err, score) {
      if (err) console.log("can't save");
    });
});

//sending data from my machine to web server
app.post('/usersearch', function(request, response){
	response.header("Access-Control-Allow-Origin", "*");
    response.header("Access-Control-Allow-Headers", "X-Requested-With");
	var user = request.body.username;
	Score.find({username: user}, function(err, scores) {
       if (err) console.log("error");
       
       if (scores.length > 0) {
         var rstring = "</br><table><caption>User Scores</caption><thead><tr><th>Game</th><th></th><th>User</th><th></th><th>Score</th><th></th><th>Date</th></tr></thead><tbody>";
         for (var i=0;i<scores.length;i++) {
           rstring += "<tr><td>";
           rstring += scores[i]['game_title'];
           rstring += "</td><td></td><td>";
           rstring += scores[i]['username'];
           rstring += "</td><td></td><td>";
           rstring += scores[i]['score'];
           rstring += "</td><td></td><td>";
           rstring += scores[i]['created_at'];
           rstring += "</td></tr>";
         }
         rstring += "</tbody></table>";
         response.send(rstring);
       }
       else { response.send("</br>No users found"); }

  });
});

app.get('/highscores.json', function(request, response) {
	var game = request.query.game_title;
	var s = Score.find({game_title: game}).sort({score: 'desc'}).limit(10);
	s.execFind(function(err, posts) {
	  if (err) console.log("error");
      response.send(posts);
	});
});

//Port set up
var port = process.env.PORT || 5000;
app.listen(port, function() {
  console.log("Listening on " + port);
});