
function getScores() {
	var namebox = document.getElementById('input');
	var name = namebox.value;
	$('#scores').empty();
	$.post("http://intense-oasis-8791.herokuapp.com/usersearch", {username: name}, function(res){
		$('#scores').append(res);
	});
	
}